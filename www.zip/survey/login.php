<?php 
	require('php/config.php');
	if((isset($_POST['email'])) && (isset($_POST['password'])))
	{
		$email=$_POST['email'];
		$password=$_POST['password'];
		
		
		$query="SELECT * from users WHERE email='$email' AND password='$password'";
		$result=$conn->query($query);
		if($result->num_rows>0)
		{
			$row = $result->fetch_assoc();
			setcookie("username",$row["email"], time() + (86400 * 30), "/");
			header("Location:location.php");	
		}
	}
?>

<html>
	<head>	
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
	<link href="frameworks/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="frameworks/font-awesome/css/font-awesome.css">
	<script src="frameworks/jquery/jquery.min.js"></script>
	<script src="frameworks/bootstrap/js/bootstrap.min.js"></script>
	
	<script type="text/javascript">
		$("document").ready(function()
		{
			$('#ulNav').empty();
			$('#ulNav').append("<li><a href='register.php'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>");
			$('#ulNav').append("<li><a href='login.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>");		
		});
	</script>
	
  	<style>
		a{
			text-decoration:none !important;
		}
		.nav a{
			color:#00a680 !important;
			font-size:15px;
			font-weight:bold;
		}
		.nav a:hover{
			background-color:#00a680 !important;
			color:white !important;
		}
		.navbar{
			padding-left:2%;
			padding-right:2%;
		}
		
		#outer {
			display: table;
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.middle {
			display: table-cell;
			vertical-align: middle;
		}

		.inner {
			margin-left: auto;
			margin-right: auto; 
			width: 400px; /*whatever width you want*/
		}

	</style>
	
	</head>   
<body class="ng-scope" >
    
	<nav class="navbar navbar-inverse navbar-fixed-top">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="#">Survey</a>
		</div>
		<ul id="ulNav" class="nav navbar-nav navbar-right">
		</ul>
	  </div>
	</nav>
	
    
    <div class="container">
        <div id="loginbox" style=" margin-top:80px;" class="mainbox col-md-4 col-md-offset-4">                    
				<center><h1 style="color:#00a680; margin-bottom:0px;">Welcome</h1></center>
				<center id="cookie" style="color:#e0162b;"></center>
				<br/>
			<div class="panel panel-info" style="border:2px solid #eee;">
                    <div class="panel-heading" style="background-color:#00a680;">
                        <div style="color:white;" class="panel-title">Sign In</div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >
                            
                        <form method="POST" class="form-horizontal" action="login.php">
                                    
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-user"></i></span>
                                        <input id="phone_number" type="text" class="form-control" name="email" value="" placeholder="Email" required>                                        
                                    </div>
                                
                            <div style="margin-bottom: 25px" class="input-group">
                                        <span class="input-group-addon"><i class="glyphicon glyphicon-lock"></i></span>
                                        <input type="password" class="form-control" name="password" placeholder="password" required>
                                    </div>
                                    

                                
                            <div class="input-group">
                                      <div class="checkbox">
                                        <label>
                                          <input type="checkbox" name="remember"> Remember me
                                        </label>
                                      </div>
                                    </div>


                                <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
										<button type="submit" id="submitBtn" style="background-color:#00a680;"class="btn btn-primary btn-lg btn-block">Login</button>
										
										<div class="group" id="warning" style="margin:10px; color:red;">
											<center><strong id="msg"></strong></center>
										</div>
										
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-md-12 control">
                                        <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                            Don't have an account! 
                                        <a href="register.php">
                                            Sign Up Here
                                        </a>
                                        </div>
                                    </div>
                                </div>    
                            </form>     
                        </div>                     
                    </div>  
        </div>
    </div>
    


    <!---- end -->
    <br>
    <br>
    <br>
	</body>
</html>