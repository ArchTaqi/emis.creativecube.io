<!--
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title></title>
</head>
<body>
    Latitude:
    <input type="text" id="txtLatitude" value="18.92488028662047" />
    Latitude:
    <input type="text" id="txtLongitude" value="72.8232192993164" />
    <input type="button" value="Get Address" onclick="GetAddress()" />
    <script type="text/javascript" src="http://maps.googleapis.com/maps/api/js?sensor=false"></script>
    <script type="text/javascript">
        function GetAddress() {
            var lat = parseFloat(document.getElementById("txtLatitude").value);
            var lng = parseFloat(document.getElementById("txtLongitude").value);
            var latlng = new google.maps.LatLng(lat, lng);
            var geocoder = geocoder = new google.maps.Geocoder();
            geocoder.geocode({ 'latLng': latlng }, function (results, status) {
                if (status == google.maps.GeocoderStatus.OK) {
                    if (results[1]) {
                        alert("Location: " + results[1].formatted_address);
                    }
                }
            });
        }
    </script>
</body>
</html>
-->

<!DOCTYPE html>
<html>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" />
  
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5xfJ3inhohNW5Yjb6XHo7i6H_t84guUA&libraries=places" type="text/javascript"></script>
	<script>
			function logout()
			{
				document.cookie = "username=; expires=Thu, 01 Jan 1970 00:00:00 UTC; path=/;";
				window.location="login.php";	
			}
			$("document").ready(function()
			{	
				var username="username"+"="
				var decodedCookie = decodeURIComponent(document.cookie);
				var ca = decodedCookie.split(';');
				for(var i = 0; i <ca.length; i++) {
					var c = ca[i];
					while (c.charAt(0) == ' ') {
						c = c.substring(1);
					}
					if (c.indexOf(username) == 0) {
						username=c.substring(username.length, c.length);
					}
				}
				if(username!="username=")
				{
					$('#ulNav').empty();
					$('#ulNav').append("<li><a>"+username+"</a></li>");	
					$('#ulNav').append("<li><a onclick='logout()'>Logout</a></li>");	
				}
				else
				{
					$('#ulNav').empty();
					$('#ulNav').append("<li><a href='register.php'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>");
					$('#ulNav').append("<li><a href='login.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>");		
				}
			});
	</script>
	
  	<style>
		a{
			text-decoration:none !important;
		}
		.nav a{
			color:#00a680 !important;
			font-size:15px;
			font-weight:bold;
		}
		.nav a:hover{
			background-color:#00a680 !important;
			color:white !important;
		}
		.navbar{
			padding-left:2%;
			padding-right:2%;
		}
		
		#outer {
			display: table;
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.middle {
			display: table-cell;
			vertical-align: middle;
		}

		.inner {
			margin-left: auto;
			margin-right: auto; 
			width: 400px; /*whatever width you want*/
		}

	</style>
	
	
<body>
	<nav class="navbar navbar-inverse navbar-fixed-top">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="#">Survey</a>
		</div>
		<ul id="ulNav" class="nav navbar-nav navbar-right">
		  
		</ul>
	  </div>
	</nav>
	
	<div class="row" style="margin-top:150px;">
	<div class="col-sm-4">
	</div>
	<div class="col-sm-4">
		<div class="col-sm-9">
		<select class="form-control selectpicker" id="select-country" data-live-search="true" name="email">	
			<?php include('php/config.php');
				$sql = "SELECT * FROM locations";
				$result = $conn->query($sql);
				$check=false;
				$rowRes="";
				if ($result->num_rows > 0) {
					
					while( $row = mysqli_fetch_array($result))
					{
						if(!$check)
						{
							$rowRes=$row['email'];
							$check=true;
							echo "<option data-tokens='".$row['email']."'>".$row['email']."</option>";
						}
						else if($rowRes!=$row['email'])
						{
							echo "<option data-tokens='".$row['email']."'>".$row['email']."</option>";
							$rowRes=$row['email'];
						}
						
					}
				}
				$conn->close();
																
			?>
			
		</select>
		</div>
		<div class="col-sm-3">
			<button onclick="locations()" class="btn">Search</button>
		</div>
	</div>
	<div class="col-sm-4">
	</div>
	</div>
	</br>
	<div class="container-fluid">
		<script>  
		var dataArray=[];
		var locationArray;
		
		function mymap(index) {
		  var data = locationArray[0][index].split(' ');
		  var myCenter = new google.maps.LatLng(data[0],data[1]);
		  var mapCanvas = document.getElementById("map");
		  var mapOptions = {center: myCenter, zoom: 5};
		  var map = new google.maps.Map(mapCanvas, mapOptions);
		  var marker = new google.maps.Marker({position:myCenter});
		  marker.setMap(map);

		  // Zoom to 9 when clicking on marker
		  google.maps.event.addListener(marker,'click',function() {
			map.setZoom(9);
			map.setCenter(marker.getPosition());
		  });
		}
		
		function locations()
		{
			$.ajax({
				type: "POST",
				url: "php/location_callback.php",
				data:{
					'email':$("[name='email']").val()
					},
				success: function(data) {
					locationArray=jQuery.parseJSON (data);
					//for(i=0;i<data[0].length;i++)
					{;
						spliting=locationArray[0][0].split(' ');
						var latlng = new google.maps.LatLng(spliting[0],spliting[1]);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									$('#locationBoxes').append("<div onclick='mymap(0)' class='col-sm-3' style='padding:0px;cursor:pointer; box-shadow: 10px 10px 5px grey;margin:5px;' ><center><h4 style='color:white;width:100%;padding:10px 15px; background-color:#00a680;'>StartingLocation</h4><h4 style='padding:5px;'>"+results[1].formatted_address+"</h4></center></div>");
								}
							}
						});
						
						spliting=locationArray[0][1].split(' ');
						var latlng = new google.maps.LatLng(spliting[0],spliting[1]);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									$('#locationBoxes').append("<div onclick='mymap(1)' class='col-sm-3' style='padding:0px;cursor:pointer; box-shadow: 10px 10px 5px grey;margin:5px;' ><center><h4 style='color:white;width:100%;padding:10px 15px; background-color:#00a680;'>Form One</h4><h4 style='padding:5px;'>"+results[1].formatted_address+"</h4></center></div>");
								}
							}
						});
						
						spliting=locationArray[0][2].split(' ');
						var latlng = new google.maps.LatLng(spliting[0],spliting[1]);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									$('#locationBoxes').append("<div onclick='mymap(2)' class='col-sm-3' style='padding:0px;cursor:pointer; box-shadow: 10px 10px 5px grey;margin:5px;' ><center><h4 style='color:white;width:100%;padding:10px 15px; background-color:#00a680;'>Form Two</h4><h4 style='padding:5px;'>"+results[1].formatted_address+"</h4></center></div>");
								}
							}
						});
						
						spliting=locationArray[0][3].split(' ');
						var latlng = new google.maps.LatLng(spliting[0],spliting[1]);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									$('#locationBoxes').append("<div onclick='mymap(3)' class='col-sm-3' style='padding:0px;cursor:pointer; box-shadow: 10px 10px 5px grey;margin:5px;' ><center><h4 style='color:white;width:100%;padding:10px 15px; background-color:#00a680;'>Form Three</h4><h4 style='padding:5px;'>"+results[1].formatted_address+"</h4></center></div>");
								}
							}
						});
						
						spliting=locationArray[0][4].split(' ');
						var latlng = new google.maps.LatLng(spliting[0],spliting[1]);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									$('#locationBoxes').append("<div onclick='mymap(4)' class='col-sm-3' style='padding:0px;cursor:pointer; box-shadow: 10px 10px 5px grey;margin:5px;' ><center><h4 style='color:white;width:100%;padding:10px 15px; background-color:#00a680;'>Form Four</h4><h4 style='padding:5px;'>"+results[1].formatted_address+"</h4></center></div>");
								}
							}
						});
						
					}
					//alert(locationArray);
					/*
					$('#locationBoxes').html("");
					for(i=0;i<dataArray.length;i++)
					{
						var d=dataArray[i]['date'];
						//$('#locationBoxes').append(d);
						var latlng = new google.maps.LatLng(dataArray[i]['lati'], dataArray[i]['longi']);
						var geocoder = geocoder = new google.maps.Geocoder();
						geocoder.geocode({ 'latLng': latlng }, function (results, status) {
							if (status == google.maps.GeocoderStatus.OK) {
								if (results[1]) {
									//alert("Location: " + );
									$('#locationBoxes').append("<div onclick=map("+i+") class='col-sm-3' style='box-shadow: 10px 10px 5px grey;padding:10px;margin:5px;' ><center><h3>"+results[1].formatted_address+"</h3></center></div>");
								}
							}
						});
					}
					*/
				},
				error: function(data) {
					alert(data);
				}
			});
		}		
		</script>

		<div class="col-sm-offset-2" id="locationBoxes">
		</div>
		
		<div id="map" style="width:100%;height:500px"></div>
		
		<script>
			var myCenter = new google.maps.LatLng(30.3753,69.3451);
			  var mapCanvas = document.getElementById("map");
			  var mapOptions = {center: myCenter, zoom: 5};
			  var map = new google.maps.Map(mapCanvas, mapOptions);
			  var marker = new google.maps.Marker({position:myCenter});
			  marker.setMap(map);

			  // Zoom to 9 when clicking on marker
			  google.maps.event.addListener(marker,'click',function() {
				map.setZoom(9);
				map.setCenter(marker.getPosition());
			  });
		  </script>
	</div>
</body>
	<div class="container-fluid" style="background-color:rgba(0,0,0,0.1); margin-top:50px; padding-top:20px;">
		<p>&copy; 2018 Al-Ahbab all rights reserved.</p>
	</div>
</html>

