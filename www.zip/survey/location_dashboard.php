<?php
	
				$con=mysqli_connect("192.169.82.14","alahbabg_numan","ahbab123!@#","alahbabg_survey");
				$data="";
				// Check connection

				if (mysqli_connect_errno())
				  {
				  echo "Failed to connect to MySQL: " . mysqli_connect_error();
				  }
				else
				{
					$sql_u="";
					//if(isset($_POST['forms']))
					{
						//$formNo=$_POST['forms'];
						
						$sql_u = "SELECT lati,longi FROM locations";
						
						$res_u = mysqli_query($con, $sql_u);
						
						if (mysqli_num_rows($res_u) > 0) 
						{
							$rows=array();
							  while($row = $res_u->fetch_assoc())
							  {
								  $rows[]=$row;
							  }
							  $data=$rows;
							//echo json_encode($rows);		
							//exit;
						}
					}
				}
				  mysqli_close($con);
?>

<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" />
  
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5xfJ3inhohNW5Yjb6XHo7i6H_t84guUA&libraries=places" type="text/javascript"></script>
	
	
	<script>
		
	</script>
	
  	<style>
		a{
			text-decoration:none !important;
		}
		.nav a{
			color:#00a680 !important;
			font-size:15px;
			font-weight:bold;
		}
		.nav a:hover{
			background-color:#00a680 !important;
			color:white !important;
		}
		.navbar{
			padding-left:2%;
			padding-right:2%;
		}
		
		#outer {
			display: table;
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.middle {
			display: table-cell;
			vertical-align: middle;
		}

		.inner {
			margin-left: auto;
			margin-right: auto; 
			width: 400px; /*whatever width you want*/
		}

	</style>
	
	</head>
<body>
		<div id="map" style="width:100%;height:420px"></div>
		
		<script type="text/javascript">
			$(document).ready(function ()
			{
				locations=<?php echo json_encode($data);?>;
						
						var map = new google.maps.Map(document.getElementById('map'), {
						  zoom: 5,
						  center: new google.maps.LatLng(-33.92, 151.25),
						  mapTypeId: google.maps.MapTypeId.ROADMAP
						});

						var infowindow = new google.maps.InfoWindow();

						var marker, i;
						//alert(locations.length);
						for (i = 0; i < locations.length; i++) 
						{
							  marker = new google.maps.Marker({
								position: new google.maps.LatLng(locations[i]['lati'], locations[i]['longi']),
								map: map
							  });
							
						  /*
						  google.maps.event.addListener(marker, 'click', (function(marker, i) {
							return function() {
							  infowindow.setContent(locations[i][0]);
							  infowindow.open(map, marker);
							}
						  })(marker, i));
						  */
						}
						map.setCenter(marker.getPosition()) ;
						
			});
		  </script>
		  
</body>
</html>

