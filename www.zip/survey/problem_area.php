<?php
	
				$con=mysqli_connect("192.169.82.14","alahbabg_numan","ahbab123!@#","alahbabg_survey");

				// Check connection

				if (mysqli_connect_errno())
				  {
				  echo "Failed to connect to MySQL: " . mysqli_connect_error();
				  }
				else
				{
					$sql_u="";
					if(isset($_POST['forms']))
					{
						$formNo=$_POST['forms'];
						
						$sql_u = "SELECT lati,longi FROM ".$formNo;
						
						$res_u = mysqli_query($con, $sql_u);
						
						if (mysqli_num_rows($res_u) > 0) 
						{
							$rows=array();
							  while($row = $res_u->fetch_assoc())
							  {
								  $rows[]=$row;
							  }
							echo json_encode($rows);		
							exit;
						}
					}
				}
				  mysqli_close($con);
?>

<html>
	<head>
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
	<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
	<link href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" rel="stylesheet" />
	<script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/js/bootstrap-select.min.js"></script>
	<link href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.10.0/css/bootstrap-select.min.css" rel="stylesheet" />
  
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyB5xfJ3inhohNW5Yjb6XHo7i6H_t84guUA&libraries=places" type="text/javascript"></script>
	
	
	<script>
		
	</script>
	
  	<style>
		a{
			text-decoration:none !important;
		}
		.nav a{
			color:#00a680 !important;
			font-size:15px;
			font-weight:bold;
		}
		.nav a:hover{
			background-color:#00a680 !important;
			color:white !important;
		}
		.navbar{
			padding-left:2%;
			padding-right:2%;
		}
		
		#outer {
			display: table;
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.middle {
			display: table-cell;
			vertical-align: middle;
		}

		.inner {
			margin-left: auto;
			margin-right: auto; 
			width: 400px; /*whatever width you want*/
		}

	</style>
	
	</head>
<body>
	<div class="row" style="margin-top:50px;">
		<div class="col-sm-4 col-sm-offset-4">
		<form id="uploadForm" method="POST" action="" >
			<select class="form-control selectpicker" name="formNo" onchange="getVal(this);" id="" data-live-search="true">
				<option>Select Form No</option>
				<option value="form1survey">Form 1</option>
				<option value="form2survey">Form 2</option>
				<option value="form3survey">Form 3</option>
				<option data-tokens="Form 4">Form 4</option>
				<option data-tokens="Form 5">Form 5</option>
				<option data-tokens="Form 6">Form 6</option>
				<option data-tokens="Form 7">Form 7</option>
				<option data-tokens="Form 8">Form 8</option>
			</select>
		</form>
	</div>
	</div>
		<center><p id="msgItemUpdate" style="display:inline-block; font:bold 15px/5px exo,sans-serif; color:#26c6da; margin-right:5px;"></p></center>
		<div id="map" style="width:100%;height:700px"></div>
		
		<script type="text/javascript">
			function getVal(sel)
			{
				document.getElementById("msgItemUpdate").innerHTML="Processing...";
				var locations;
				//alert(sel.value);
				$.ajax({
					type: "POST",
					url: "problem_area.php",
					data:{
						'forms': sel.value
					},
					success: function(data) {
						locations=jQuery.parseJSON(data);
						//alert(data[0]['lati']);
						
						/*
						var locations = [
						  ['', -33.890542, 151.274856, 4],
						  ['', -33.923036, 151.259052, 5],
						  ['', -34.028249, 151.157507, 3],
						  ['', -33.80010128657071, 151.28747820854187, 2],
						  ['', -33.950198, 151.259302, 1]
						];
						*/
						
						
						
						var map = new google.maps.Map(document.getElementById('map'), {
						  zoom: 5,
						  center: new google.maps.LatLng(-33.92, 151.25),
						  mapTypeId: google.maps.MapTypeId.ROADMAP
						});

						var infowindow = new google.maps.InfoWindow();

						var marker, i;
						//alert(locations.length);
						for (i = 0; i < locations.length; i++) 
						{
							  marker = new google.maps.Marker({
								position: new google.maps.LatLng(locations[i]['lati'], locations[i]['longi']),
								map: map
							  });
							
						  /*
						  google.maps.event.addListener(marker, 'click', (function(marker, i) {
							return function() {
							  infowindow.setContent(locations[i][0]);
							  infowindow.open(map, marker);
							}
						  })(marker, i));
						  */
						}
						map.setCenter(marker.getPosition()) ;
						document.getElementById("msgItemUpdate").innerHTML="Done";
					},
					error: function(data) {
						//alert(data['error']);
					}
				});		
			}
		  </script>
		  
	</div>
</body>
</html>

