<?php
	include('config.php');
	if(isset($_POST['email']))
	{
		$email=$_POST['email'];
		$sql="SELECT * from locations WHERE email='$email'";
		$result = $conn->query($sql);
		if ($result->num_rows > 0) {
			$rows = array();		
			while( $row = mysqli_fetch_array($result))
			{
				$row_array[0]=$row['startingLocation'];
				$row_array[1]=$row['formOne'];
				$row_array[2]=$row['formTwo'];
				$row_array[3]=$row['formThree'];
				$row_array[4]=$row['formFour'];
				
				array_push($rows,$row_array);
			}
			echo json_encode($rows);
		}
	}
	$conn->close();
?>