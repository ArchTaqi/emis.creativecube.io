<?php 
	require('php/config.php');
	if((isset($_POST['first_name'])) && (isset($_POST['phone_number'])))
	{
		$first_name=$_POST['first_name'];
		$last_name=$_POST['last_name'];
		$phone_number=$_POST['phone_number'];
		$email=$_POST['email'];
		$password=$_POST['password'];
		$confirmPassword=$_POST['confirmPassword'];
		
		
		if($password==$confirmPassword)
		{
			$query="INSERT INTO register VALUES('$first_name','$last_name','$phone_number','$email','$password')";
			$result=mysqli_query($conn,$query);
			if($result)
			{
				setcookie("username",$first_name.' '.$last_name, time() + (86400 * 30), "/");
				header("Location:index.php");	
			}
			
		}
		else
		{
			echo "Password Mismatch";
		}
	}
?>
<html>
	<head>	
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    
	<link href="frameworks/bootstrap/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	<link rel="stylesheet" type="text/css" href="frameworks/font-awesome/css/font-awesome.css">
	<script src="frameworks/jquery/jquery.min.js"></script>
	<script src="frameworks/bootstrap/js/bootstrap.min.js"></script>
	
	<script type="text/javascript">
		$("document").ready(function()
		{
			$('#ulNav').empty();
			$('#ulNav').append("<li><a href='register.php'><span class='glyphicon glyphicon-user'></span> Sign Up</a></li>");
			$('#ulNav').append("<li><a href='login.php'><span class='glyphicon glyphicon-log-in'></span> Login</a></li>");		
		});
	</script>
	
  	<style>
		a{
			text-decoration:none !important;
		}
		.nav a{
			color:#00a680 !important;
			font-size:15px;
			font-weight:bold;
		}
		.nav a:hover{
			background-color:#00a680 !important;
			color:white !important;
		}
		.navbar{
			padding-left:2%;
			padding-right:2%;
		}
		
		#outer {
			display: table;
			position: absolute;
			height: 100%;
			width: 100%;
		}

		.middle {
			display: table-cell;
			vertical-align: middle;
		}

		.inner {
			margin-left: auto;
			margin-right: auto; 
			width: 400px; /*whatever width you want*/
		}

	</style>
	
	</head>   
<body class="ng-scope" >
        
	<nav class="navbar navbar-inverse navbar-fixed-top">
	  <div class="container-fluid">
		<div class="navbar-header">
		  <a class="navbar-brand" href="#">Survey</a>
		</div>
		<ul id="ulNav" class="nav navbar-nav navbar-right">
		</ul>
	  </div>
	</nav>
	

    <div class="container">
        <div id="loginbox" style=" margin-top:80px;" class="mainbox col-md-4 col-md-offset-4">
				<br/>
			<div class="panel panel-info" style="border:2px solid #eee;">
                    <div class="panel-heading" style="background-color:#00a680;">
                        <div style="color:white;" class="panel-title">Register</div>
                    </div>     

                    <div style="padding-top:30px" class="panel-body" >
                            
                        <form method="POST" class="form-horizontal" action="register.php">
                                    
                            <div style="margin-bottom: 25px">
                                <input type="text" class="form-control" name="first_name" value="" placeholder="First Name" required>                                        
                            </div>
                            
							<div style="margin-bottom: 25px">
                                <input type="text" class="form-control" name="last_name" value="" placeholder="Last Name" required>                                        
                            </div>
							
                            <div style="margin-bottom: 25px">
                                <input type="text" class="form-control" name="phone_number" value="" placeholder="Phone Number" required>                                        
                            </div>        

                            <div style="margin-bottom: 25px">
                                <input type="text" class="form-control" name="email" value="" placeholder="Email Address" required>                                        
                            </div>
							
							<div style="margin-bottom: 25px">
                                <input type="password" class="form-control" name="password" value="" placeholder="Password" required>                                        
                            </div>
							
							<div style="margin-bottom: 25px">
                                <input type="password" class="form-control" name="confirmPassword" value="" placeholder="Confirm Password" required>                                        
                            </div>
							

                                <div style="margin-top:10px" class="form-group">
                                    <!-- Button -->

                                    <div class="col-sm-12 controls">
										<button type="submit" id="submitBtn" style="background-color:#00a680;"class="btn btn-primary btn-lg btn-block">Resgister</button>
										
										
                                    </div>
                                </div>


                                <div class="form-group">
                                    <div class="col-md-12 control">
                                        <div style="border-top: 1px solid#888; padding-top:15px; font-size:85%" >
                                            Do have an account! 
                                        <a href="login.php">
                                            Sign In Here
                                        </a>
                                        </div>
                                    </div>
                                </div>    
                            </form>     
                        </div>                     
                    </div>  
        </div>
    </div>
    


    <!---- end -->
    <br>
    <br>
    <br>
	</body>
</html>