<!DOCTYPE html>
<html>
<body>

<?php
	$rows=array();
	$myfile = fopen("cities.txt", "r") or die("Unable to open file!");
	while(!feof($myfile)) 
	{
		$rows[]=fgets($myfile);
		
		echo fgets($myfile) . "<br>";
	}
fclose($myfile);

	//echo $rows;
?>
</body>
</html>
