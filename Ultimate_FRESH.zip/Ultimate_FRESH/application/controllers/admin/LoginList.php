<?php

/**
 * Description of training
 *
 * @author Ashraf
 */
class LoginList extends Admin_Controller
{
    public function index()
    {
        $data['title'] ="Login List";
		//$data['check'] =$this->hash("12345");
        $data['subview'] = $this->load->view('admin/loginlist/loginList', $data, TRUE);
        $this->load->view('admin/_layout_main', $data);
    }
	
	public function hash($string)
    {
        return hash('sha512', $string . config_item('encryption_key'));
    }
	
}
