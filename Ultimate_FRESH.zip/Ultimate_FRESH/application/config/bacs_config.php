<?php
$config['site_name'] = 'BACS-Billing accounting and CRM Software';
