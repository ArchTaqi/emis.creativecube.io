<?php
$lang['menu_permission'] = 'menu Toestemming  ';
$lang['module'] = ' module';
$lang['department_update'] = ' Afdeling Infromation succesvol bijwerken';
$lang['designation_info_deleted'] = ' Aanwijzing Infromation succesvol verwijderd';
$lang['no_designation_create_yet'] = ' GeenNaam Maak nog  ';
$lang['department_already_used'] = ' Afdeling Information al gebruikt';
$lang['undefined_department'] = ' undefined Department';
$lang['activity_update_a_department'] = ' update-afdeling';
$lang['activity_delete_a_department'] = ' Verwijderde Department';
$lang['activity_delete_a_designation'] = ' aanwijzing Deleted';


/* End of file departments_lang.php */
/* Location: ./application/language/dutch/departments_lang.php */
