<?php
$lang['bugs'] = ' bugs';
$lang['bugs_email'] = ' bugs E-mail  ';
$lang['bug_assigned'] = ' bug Toegewezen  ';
$lang['bug_comments'] = ' bug Comments';
$lang['bug_attachment'] = ' bug Attachment  ';
$lang['bug_updated'] = ' bug Bijgewerkt  ';
$lang['bug_reported'] = ' bug Gerapporteerde  ';
$lang['update_bug'] = ' Bugs infromation bijgewerkt';
$lang['save_bug'] = ' Bugs infromation succesvol opgeslagen';
$lang['delete_timesheet'] = ' Timer infromation succesvol verwijderd';
$lang['bug_deleted'] = ' Bugs infromation succesvol verwijderd  ';
$lang['activity_delete_tasks_timesheet'] = ' Taken Timesheet verwijderd';
$lang['activity_update_task_timesheet'] = ' Taken Timesheet Bijgewerkt';
$lang['activity_update_bug'] = ' Bugs activiteit update';
$lang['activity_new_bug_comment'] = ' Activiteit Bugs nieuwe Reacties';
$lang['activity_bug_attachfile_deleted'] = ' Activiteit Bugs Attachment Verwijderde  ';
$lang['activity_new_bug_attachment'] = ' Activiteit Bugs Bevestig een nieuwe bestanden';
$lang['activity_bug_deleted'] = ' Activiteit Bugs Verwijderde';
$lang['activity_new_bug'] = ' Activiteit nieuwe bugs Toegevoegd  ';
$lang['all_bugs'] = ' alle Bugs';
$lang['new_bugs'] = ' nieuwe Bugs';
$lang['bug_status'] = ' bug Status  ';
$lang['bug_title'] = ' bug Titel';
$lang['resolved'] = ' Vastbesloten';
$lang['update_on'] = ' update over';
$lang['bug_details'] = ' bugs Details';


/* End of file bugs_lang.php */
/* Location: ./application/language/dutch/bugs_lang.php */
