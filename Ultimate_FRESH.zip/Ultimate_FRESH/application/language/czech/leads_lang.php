<?php
$lang['recent_leads'] = 'Nedávné Vede';
$lang['source'] = 'Zdroj';
$lang['facebook_profile_link'] = 'Zdroj';
$lang['twitter_profile_link'] = 'Zdroj';
$lang['linkedin_profile_link'] = 'Zdroj';
$lang['leads_name'] = 'vede Jméno';
$lang['mettings_deleted'] = 'Mettings informace úspěšně ';
$lang['convert'] = 'Konvertovat';
$lang['convert_to_client'] = 'Převést na klientovi';
$lang['activity_convert_to_client'] = 'Převést vést ke klientovi';
$lang['convert_to_client_suucess'] = 'Převést vést ke klientovi úspěšně';
$lang['import_leads'] = 'dovozní Vede';


/* End of file leads_lang.php */
/* Location: ./application/language/czech/leads_lang.php */
