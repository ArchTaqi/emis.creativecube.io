<?php
$lang['menu_permission'] = ' Menü Permission';
$lang['module'] = ' Modul';
$lang['department_update'] = 'Abteilung Infromation Erfolgreich -Update';
$lang['designation_info_deleted'] = 'Bezeichnung Infromation erfolgreich gelöscht';
$lang['no_designation_create_yet'] = 'Erstellen Sie keine Bezeichnung noch';
$lang['department_already_used'] = 'Abteilung Information bereits benutzt';
$lang['undefined_department'] = 'Nicht definierte Abteilung';
$lang['activity_update_a_department'] = 'Update- Abteilung';
$lang['activity_delete_a_department'] = ' Gelöscht Abteilung';
$lang['activity_delete_a_designation'] = 'Bezeichnung Deleted';
$lang['department_info_deleted'] = 'Abteilungsinformationen erfolgreich gelöscht';
$lang['designation_already_used'] = 'Diese Bezeichnung ist den Benutzern bereits zugewiesen. Bitte ändern Sie die Bezeichnung von den Benutzern. Dann können Sie die Bezeichnung löschen';
$lang['create'] = 'Erstellen';
$lang['view_help'] = 'Wenn Sie Erstellen / Bearbeiten / Löschen auswählen, müssen Sie die Ansicht nicht auswählen';
$lang['set_full_permission'] = 'Legen Sie vollständige Berechtigungen für diese Bezeichnung fest';


/* End of file departments_lang.php */
/* Location: ./application/language/german/departments_lang.php */
