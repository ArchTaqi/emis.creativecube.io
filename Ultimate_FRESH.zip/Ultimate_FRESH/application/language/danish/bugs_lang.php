<?php
$lang['bugs'] = 'Bugs infromation opdateret';
$lang['bugs_email'] = 'Bugs infromation opdateret';
$lang['bug_assigned'] = 'Bugs infromation opdateret';
$lang['bug_comments'] = 'Bugs infromation opdateret';
$lang['bug_attachment'] = 'Bugs infromation opdateret';
$lang['bug_updated'] = 'Bugs infromation opdateret';
$lang['bug_reported'] = 'Bugs infromation opdateret';
$lang['update_bug'] = 'Bugs infromation opdateret';
$lang['save_bug'] = 'Bugs infromation opdateret';
$lang['delete_timesheet'] = 'Bugs infromation opdateret';
$lang['bug_deleted'] = 'Bugs infromation opdateret';
$lang['activity_delete_tasks_timesheet'] = 'Bugs infromation opdateret';
$lang['activity_update_task_timesheet'] = 'Bugs infromation opdateret';
$lang['activity_update_bug'] = 'Bugs infromation opdateret';
$lang['activity_new_bug_comment'] = 'Bugs infromation opdateret';
$lang['activity_bug_attachfile_deleted'] = 'Bugs infromation opdateret';
$lang['activity_new_bug_attachment'] = 'Bugs infromation opdateret';
$lang['activity_bug_deleted'] = 'Bugs infromation opdateret';
$lang['activity_new_bug'] = 'Bugs infromation opdateret';
$lang['all_bugs'] = 'Bugs infromation opdateret';
$lang['new_bugs'] = 'Bugs infromation opdateret';
$lang['bug_status'] = 'Bugs infromation opdateret';
$lang['bug_title'] = 'Bugs infromation opdateret';
$lang['resolved'] = 'Bugs infromation opdateret';
$lang['update_on'] = 'Bugs infromation opdateret';
$lang['bug_details'] = ' Detaljer';


/* End of file bugs_lang.php */
/* Location: ./application/language/danish/bugs_lang.php */
