<?php
$lang['performance'] = 'Ydeevne';
$lang['performance_indicator'] = 'Indikator';
$lang['give_appraisal'] = 'Giv Vurdering';
$lang['performance_report'] = 'effektivitetsrapport';
$lang['indicator_list'] = 'Indikator List';
$lang['set_indicator'] = 'Set indikator';
$lang['technical_competency'] = 'Tekniske Kompetencer';
$lang['customer_experience_management'] = 'Begynder';
$lang['beginner'] = 'Begynder';
$lang['intermediate'] = 'Begynder';
$lang['advanced'] = 'Begynder';
$lang['expert_leader'] = 'Begynder';
$lang['marketing'] = 'Begynder';
$lang['management'] = 'Begynder';
$lang['administration'] = 'Begynder';
$lang['presentation_skill'] = 'Begynder';
$lang['quality_of_work'] = 'Begynder';
$lang['efficiency'] = 'Begynder';
$lang['behavioural_competency'] = 'Begynder';
$lang['integrity'] = 'Begynder';
$lang['professionalism'] = 'Begynder';
$lang['team_work'] = 'Begynder';
$lang['critical_thinking'] = 'Begynder';
$lang['conflict_management'] = 'Begynder';
$lang['attendance'] = 'Begynder';
$lang['ability_to_meet_deadline'] = 'BegynderBegynder';
$lang['activity_performance_indicator_saved'] = 'Begynder';
$lang['activity_performance_indicator_updated'] = 'Begynder';
$lang['indicator_update'] = 'Begynder';
$lang['indicator_saved'] = 'Begynder';
$lang['performance_indicator_details'] = 'Begynder';
$lang['indicator_value_not_set'] = 'Begynder';
$lang['give_performance_appraisal'] = 'Begynder';
$lang['remarks'] = 'Begynder';
$lang['expected_value'] = 'Begynder';
$lang['set_value'] = 'Begynder';
$lang['not_set'] = 'Begynder';
$lang['appraisal_already_provided'] = 'Begynder';
$lang['activity_appraisal_update'] = 'Begynder';
$lang['activity_appraisal_saved'] = 'Begynder';
$lang['appraisal_update'] = 'Begynder';
$lang['appraisal_saved'] = 'Begynder';
$lang['emp_id'] = 'Begynder';
$lang['appraisal_month'] = 'BegynderBegynder';
$lang['performance_appraisal_details'] = 'Begynder';
$lang['performance_appraisal_of'] = 'Begynder';
$lang['assigned'] = 'Begynder';
$lang['expected'] = 'Begynder';
$lang['atleast_one_appraisal'] = 'Begynder';


/* End of file performance_lang.php */
/* Location: ./application/language/danish/performance_lang.php */
