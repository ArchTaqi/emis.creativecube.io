<?php
$lang['menu_permission'] = ' Menu Permission';
$lang['module'] = ' Module';
$lang['department_update'] = 'Département Infromation avec succès Mise à jour';
$lang['designation_info_deleted'] = 'Désignation Infromation supprimé avec succès';
$lang['no_designation_create_yet'] = ' No Désignation Créer encore';
$lang['department_already_used'] = 'Département de l\'information déjà utilisé';
$lang['undefined_department'] = 'Département undefined';
$lang['activity_update_a_department'] = 'Mise à jour Département';
$lang['activity_delete_a_department'] = 'Département supprimé';
$lang['activity_delete_a_designation'] = ' Désignation Supprimé';


/* End of file departments_lang.php */
/* Location: ./application/language/french/departments_lang.php */
