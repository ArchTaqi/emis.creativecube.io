<?php
$lang['bugs'] = 'για ειδικό προορισμό';
$lang['bugs_email'] = 'για ειδικό προορισμό';
$lang['bug_assigned'] = 'για ειδικό προορισμό';
$lang['bug_comments'] = 'για ειδικό προορισμό';
$lang['bug_attachment'] = 'για ειδικό προορισμό';
$lang['bug_updated'] = 'για ειδικό προορισμό';
$lang['bug_reported'] = 'για ειδικό προορισμό';
$lang['update_bug'] = 'για ειδικό προορισμό';
$lang['save_bug'] = 'για ειδικό προορισμό';
$lang['delete_timesheet'] = 'για ειδικό προορισμό';
$lang['bug_deleted'] = 'για ειδικό προορισμό';
$lang['activity_delete_tasks_timesheet'] = 'για ειδικό προορισμό';
$lang['activity_update_task_timesheet'] = 'για ειδικό προορισμό';
$lang['activity_update_bug'] = 'για ειδικό προορισμό';
$lang['activity_new_bug_comment'] = 'για ειδικό προορισμό';
$lang['activity_bug_attachfile_deleted'] = 'για ειδικό προορισμό';
$lang['activity_new_bug_attachment'] = 'για ειδικό προορισμό';
$lang['activity_bug_deleted'] = 'για ειδικό προορισμό';
$lang['activity_new_bug'] = 'για ειδικό προορισμό';
$lang['all_bugs'] = 'για ειδικό προορισμό';
$lang['new_bugs'] = 'για ειδικό προορισμό';
$lang['bug_status'] = 'για ειδικό προορισμό';
$lang['bug_title'] = 'για ειδικό προορισμό';
$lang['resolved'] = 'για ειδικό προορισμό';
$lang['update_on'] = 'για ειδικό προορισμό';
$lang['bug_details'] = 'για ειδικό προορισμό';


/* End of file bugs_lang.php */
/* Location: ./application/language/greek/bugs_lang.php */
