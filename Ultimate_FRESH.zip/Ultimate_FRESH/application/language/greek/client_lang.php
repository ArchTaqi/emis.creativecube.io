<?php
$lang['client_list'] = 'Λίστα πελάτη';
$lang['all_client'] = 'Όλες οι Πελάτες';
$lang['name'] = 'Όνομα';
$lang['client'] = 'Πελάτης';
$lang['clients'] = 'Πελάτης';
$lang['client_status'] = 'Πελάτης';
$lang['select'] = 'Πελάτης';
$lang['manage_client'] = 'Πελάτης';
$lang['clients_registration'] = 'Πελάτης';
$lang['clients_registered'] = 'Πελάτης';
$lang['client_registered_successfully'] = 'Πελάτης';
$lang['activity_added_new_company'] = 'Πελάτης';
$lang['activity_update_company'] = 'Πελάτης';
$lang['activity_update_contact'] = 'Πελάτης';
$lang['activity_added_new_contact'] = 'Πελάτης';
$lang['activity_deleted_contact'] = 'Πελάτης';
$lang['delete_contact'] = 'Πελάτης';
$lang['activity_deleted_client'] = 'Πελάτης';
$lang['delete_client'] = 'Πελάτης';
$lang['select_type'] = 'Πελάτης';
$lang['client_contact'] = 'Πελάτης';
$lang['hosting'] = 'Πελάτης';
$lang['converted_from'] = 'Πελάτης';
$lang['without_converted'] = 'Πελάτης';
$lang['converted_client'] = 'Πελάτης';


/* End of file client_lang.php */
/* Location: ./application/language/greek/client_lang.php */
