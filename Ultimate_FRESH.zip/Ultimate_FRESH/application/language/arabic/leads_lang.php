<?php
$lang['recent_leads'] = 'العروض الأخيرة';
$lang['source'] = 'مصدر';
$lang['facebook_profile_link'] = 'RL الفيسبوك';
$lang['twitter_profile_link'] = 'RL تويتر';
$lang['linkedin_profile_link'] = 'RL ينكدين';
$lang['leads_name'] = 'يؤدي اسم';
$lang['mettings_deleted'] = 'معلومات اجتماعات المحذوفة بنجاح';
$lang['convert'] = 'تحول';
$lang['convert_to_client'] = 'تحويل إلى العميل';
$lang['activity_convert_to_client'] = 'تحويل الرصاص إلى العميل';
$lang['convert_to_client_suucess'] = 'تحويل لقيادة العميل بنجاح';
$lang['import_leads'] = 'العروض استيراد';


/* End of file leads_lang.php */
/* Location: ./application/language/arabic/leads_lang.php */
